<template>
  <div class="search">
    <div class="inp">
      <span class="search-btn"></span>
      <input type="text" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'Search',
  data () {
    return {
      
    }
  },
  components: {
    
  },
  created () {

  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">
@import "~assets/stylus/index";
.search-btn {
    
}

</style>
