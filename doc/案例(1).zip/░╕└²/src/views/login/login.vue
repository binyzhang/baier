<template>
  <div class="login">
    <div class="login-wrapper">
      login
    </div>
  </div>
</template>

<script>
export default {
  name: 'login'
}
</script>

<style scoped>

</style>
